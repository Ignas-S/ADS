﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graph_Shortest_Path
{
    class Dijkstra_Algorithm
    {
        public List<string> verticeNames;
        int vertexOut;

        private static readonly int NO_PARENT = -1;

        //Find and prints the shortest path to all other points in the matrix
        public void dijkstra(int[,] adjacencyMatrix, int startVertex)
        {
            int nVertices = adjacencyMatrix.GetLength(0);

            int[] shortestDistances = new int[nVertices];

            bool[] added = new bool[nVertices];

            // Initialize all distances as INFINITE and added[] as false  
            for (int vertexIndex = 0; vertexIndex < nVertices;
                                                vertexIndex++)
            {
                shortestDistances[vertexIndex] = int.MaxValue;
                added[vertexIndex] = false;
            }

            // Distance from itself is 0 
            shortestDistances[startVertex] = 0;

            // Parent array to store shortest path tree (references where to go)
            int[] parents = new int[nVertices];

            // The starting vertex does not have a parent  
            parents[startVertex] = NO_PARENT;

            // Find shortest path for all vertices  
            for (int i = 1; i < nVertices; i++)
            {

                // Pick the minimum distance vertex that is not yet marked. Is always the source point in first iteration.
                int nearestVertex = -1;
                int shortestDistance = int.MaxValue;
                for (int vertexIndex = 0; vertexIndex < nVertices; vertexIndex++)
                {
                    if (!added[vertexIndex] && shortestDistances[vertexIndex] < shortestDistance)
                    {
                        nearestVertex = vertexIndex;
                        shortestDistance = shortestDistances[vertexIndex];
                    }
                }

                // Mark the picked vertex 
                added[nearestVertex] = true;

                //If there is a connection between two vertexes, and the path is shorter than the current one, update the distances
                for (int vertexIndex = 0; vertexIndex < nVertices; vertexIndex++)
                {
                    int edgeDistance = adjacencyMatrix[nearestVertex, vertexIndex];

                    if (edgeDistance > 0 && ((shortestDistance + edgeDistance) < shortestDistances[vertexIndex]))
                    {
                        parents[vertexIndex] = nearestVertex;
                        shortestDistances[vertexIndex] = shortestDistance + edgeDistance;
                    }
                }
            }
            printSolution(startVertex, shortestDistances, parents);
        }

        private void printSolution(int startVertex, int[] distances, int[] parents)
        {
            int nVertices = distances.Length;
            Console.Write(string.Format("| {0,-20} | {1, -20} | {2, -90}\n", "Vertex", "Price", "Path"));
            Console.WriteLine("---------------------------------------------------------------------------------------------------------------");
            for (int vertexIndex = 0; vertexIndex < nVertices; vertexIndex++)
            {
                if (vertexIndex != startVertex)
                {
                    if (distances[vertexIndex] != int.MaxValue)
                    {
                        Console.Write(string.Format("| {0,-20} | {1, -20} | ", startVertex + "->" + vertexIndex, distances[vertexIndex]));
                        vertexOut = vertexIndex;
                        printPath(vertexIndex, parents);
                        Console.Write("\n");
                    }
                    else Console.Write(string.Format("| {0,-20} | {1, -20} | ", startVertex + "->" + vertexIndex, "UNREACHABLE"));
                }
            }
            foreach (int i in parents) Console.WriteLine(i);
        }

        //Recursive function which backtracks the path from every point
        private void printPath(int currentVertex,
                                    int[] parents)
        {

            // Base case : reached the source point
            if (currentVertex == NO_PARENT)
            {
                return;
            }

            printPath(parents[currentVertex], parents);
            if (verticeNames != null && verticeNames.Count() > currentVertex) Console.Write(verticeNames[currentVertex]);
            else Console.Write(currentVertex);
            if (vertexOut != currentVertex) Console.Write(", ");

        }
    }
}

