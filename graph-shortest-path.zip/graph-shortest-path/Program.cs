﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graph_Shortest_Path
{
    class Program
    {
        public static void Main(string[] args)
        { 
            int[,] graph = new int[,] { {  0, 17, 11, 18,  0,  0,  0,  0,  0,  0 },
                                        { 17,  0,  0,  0,  0,  0,  9,  0,  0,  0 },
                                        { 11,  0,  0, 16, 15, 12,  0,  0,  0,  0 },
                                        { 18,  0, 16,  0,  0,  0,  0,  0,  0,  0 },
                                        {  0,  0, 15,  0,  0,  0, 10,  5, 11,  0 },
                                        {  0,  0, 12,  0,  0,  0,  0,  0, 19,  0 },
                                        {  0,  9,  0,  0, 10,  0,  0, 13,  0,  0 },
                                        {  0,  0,  0,  0,  5,  0, 13,  0,  4,  0 },
                                        {  0,  0,  0,  0, 11, 19,  0,  4,  0,  0 },
                                        {  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 } };
             
            Dijkstra_Algorithm da = new Dijkstra_Algorithm();

            da.verticeNames = new List<string>(new string[] { "Narnia", "WC", "Israel", "Warzone", "Whiterun", "Lothric", "Stutthof", "Ashina", "The Void", "Kiln of the First Flame" });

            da.dijkstra(graph, 0);
            Console.ReadLine();
            
        }
    }
}
