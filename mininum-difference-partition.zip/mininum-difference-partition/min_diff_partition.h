#ifndef MIN_DIFF_PARTITION_H
#define MIN_DIFF_PARTITION_H

void partitionRecurse(unsigned int i, long &diffcurrent, long sum1, long sum2);
void partitionMinDiff(std::vector<int> &, std::vector<int> &, std::vector<int>, long &);

#endif // MIN_DIFF_PARTITION_H
